package com.ciclo3.reto.Interfaces;

import org.springframework.data.repository.CrudRepository;

import com.ciclo3.reto.Modelos.ClienteModel;

public interface ClientesRepository extends CrudRepository<ClienteModel,Long> {



}
