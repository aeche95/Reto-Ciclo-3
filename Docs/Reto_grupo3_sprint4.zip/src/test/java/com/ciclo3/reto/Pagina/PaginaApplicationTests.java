package com.ciclo3.reto.Pagina;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginaApplicationTests {

	@Test
	void contextLoads() {
	}

}
