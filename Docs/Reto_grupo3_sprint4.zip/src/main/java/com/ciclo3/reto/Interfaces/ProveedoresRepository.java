package com.ciclo3.reto.Interfaces;

import org.springframework.data.repository.CrudRepository;

import com.ciclo3.reto.Modelos.ProveedorModel;

public interface ProveedoresRepository extends CrudRepository<ProveedorModel,Long> {

}
